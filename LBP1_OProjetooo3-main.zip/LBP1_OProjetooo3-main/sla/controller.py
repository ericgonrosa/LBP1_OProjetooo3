from flask import render_template, request, redirect, url_for, flash, session, Blueprint
from models import User

controlador = Blueprint("login", __name__)

@controlador.route("/")
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.get_user(username)

        if user and user.password == password:
            session['username'] = user.username  # Armazena usuário na sessão
            flash('Login realizado com sucesso!', 'success')
            return redirect(url_for('protected_route'))
        else:
            flash('Usuário ou senha incorretos.', 'danger')
            return redirect(url_for('login.login'))

    return render_template('index.html')

def protected_route():
    return 'Bem-vindo ao Dashboard!'

def logout():
    session.pop('username', None)  # Remove o usuário da sessão
    flash('Você saiu com sucesso.', 'info')
    return redirect(url_for('login'))