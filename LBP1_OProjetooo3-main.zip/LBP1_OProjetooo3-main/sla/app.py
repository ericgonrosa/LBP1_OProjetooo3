from flask import Flask, session, redirect, url_for, request, flash, render_template, make_response
from controller import controlador
import logging
from flask import abort

app = Flask(__name__)
app.secret_key = 'sua_chave_secreta_aqui'

app.register_blueprint(controlador)

@app.before_request
def require_login():
    allowed_routes = ['login.login', 'logout.logout']
    if request.endpoint not in allowed_routes and 'username' not in session:
        return redirect(url_for('login.login'))



# app.add_url_rule('/', view_func=login, methods=['GET', 'POST'])
# app.add_url_rule('/dashboard', view_func=protected_route)
# app.add_url_rule('/logout', view_func=logout)


@app.route('/set_cookie')
def set_cookie():
    resp = make_response("Cookie has been set!")
    resp.set_cookie('Username', 'Atena', max_age=60*60*24)
    return resp

@app.route('/set_cookie')
def set_cookie():
    username = request.cookies.get('username')
    if (username):
        return f'The username is {username}'
    else:
        return 'No cookie found!'

@app.route('/delete_cookie')
def delete_cookie():
    resp = make_response("Cookie has been set!")
    resp.set_cookie('Username', '', expires=0)
    return resp

app.secret_key = 'your_secret_key'

@app.route('/submit', methods=['POST'])
def submit():
    flash('Formulário enviado com sucesso!', 'success')
    return redirect(url_for('index'))

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(ZeroDivisionError)
def handle_zero_division_error(e):
    return render_template('error.html', message="Ocorreu uma divisão por zero"), 500

@app.errorhandler(Exception)
def handle_generic_error(e):
    return render_template('generic_error.html', message=str(e)), 500

logging.basicConfig(filename='error.log', level=logging.ERROR)

@app.errorhandler(500)
def internal_server_error(e):
    app.logger.error(f"Erro 500: {e}")
    return render_template('500.html'), 500

@app.route('/admin')
def admin():
    abort(403)

if __name__ == '__main__':
    app.run(debug=True)